
void latitude()
{
   int n = 45;
   double pi = 180.;
   double rate = pi/n;

   double x, y;

   ofstream out1("lat60.dat");
   ofstream out2("lat-60.dat");
   ofstream out3("lat120.dat");
   ofstream out4("lat-120.dat");
   ofstream out5("lat180.dat");
   ofstream out6("lat-180.dat");
   ofstream out7("lat0.dat");
   for (int i = 0; i <= n; ++i) {
      double theta = rate*i - 90;
      THistPainter::ProjectAitoff2xy(60.,theta,x,y);
      out1 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(-60.,theta,x,y);
      out2 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(120.,theta,x,y);
      out3 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(-120.,theta,x,y);
      out4 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(180.,theta,x,y);
      out5 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(-180.,theta,x,y);
      out6 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(0.,theta,x,y);
      out7 << x << " " << y << "\n";
   }
}

void longitude()
{
   int n = 180;
   double twopi = 360.;
   double rate = twopi/n;

   double x, y;

   ofstream out1("longitude30.dat");
   ofstream out2("longitude-30.dat");
   ofstream out3("longitude60.dat");
   ofstream out4("longitude-60.dat");
   ofstream out5("longitude90.dat");
   ofstream out6("longitude-90.dat");
   ofstream out7("longitude0.dat");
   for (int i = 0; i < n; ++i) {
      double phi = rate*i - 180;
      THistPainter::ProjectAitoff2xy(phi,30,x,y);
      out1 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,-30,x,y);
      out2 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,60,x,y);
      out3 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,-60,x,y);
      out4 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,90,x,y);
      out5 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,-90,x,y);
      out6 << x << " " << y << "\n";
      THistPainter::ProjectAitoff2xy(phi,0,x,y);
      out7 << x << " " << y << "\n";
   }
}

