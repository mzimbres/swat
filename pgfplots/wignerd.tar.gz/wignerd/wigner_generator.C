
void wig2ascii(Int_t l,Int_t m,Int_t n,const char* file);

void wigner_generator()
{
   // Generate data files

   wig2ascii(50,10,0,"wig1.dat");
   wig2ascii(50,10,10,"wig2.dat");
   wig2ascii(50,10,30,"wig3.dat");
}

void wig2ascii(Int_t l,Int_t m,Int_t n,const char* file)
{
   // This macro can be used to draw the graph of 
   // a Wigner d function.

   Int_t L = 1024;
   if (l > L)
      L = l;

   // The number of points on which the function will be sampled
   // is 2*L.

   const Int_t size = 2*L;

   TWignerd wig(l);
   wig.Advance(l);

   TSmallWignerd smallwd(L);

   Double_t *vecy = smallwd.Get(wig,m,n);

   ofstream out(file);
   if (!out.good()) {
      cerr << "Unable to create file wig.dat" << endl;
      return;
   }

   Double_t vecx[size];

   for (Int_t j = 0; j < size; ++j) {
      vecx[j] = TMath::Pi()*(j + 1/2)/size;
      out << vecx[j] << " " << vecy[j] << "\n";
   }
}

